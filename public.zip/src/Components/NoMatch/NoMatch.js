import React from "react";

const NoMatch = () => {
  return (
    <div>
      <h3>No Match</h3>
    </div>
  );
};

export default NoMatch;
